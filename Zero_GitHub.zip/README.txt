GitHub se APK banane ke steps (phone browser):
1. github.com par account > New repository (naam: Zero)
2. "uploading an existing file" par tap karo, is zip ko extract karke SAARI files/folders upload karo
   (.github folder zaroor upload karna)
3. Actions tab > "Build Zero APK" > Run workflow (ya upload par khud chalta hai)
4. 5-10 min baad build ke andar Artifacts > Zero-APK download karo
5. Zip extract karke app-debug.apk install karo
