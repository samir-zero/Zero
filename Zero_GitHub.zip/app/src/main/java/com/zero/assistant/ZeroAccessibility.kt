package com.zero.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class ZeroAccessibility : AccessibilityService() {
    companion object { var inst: ZeroAccessibility? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: android.content.Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun shot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }
    fun swipe(down: Boolean) {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
        if (down) gesture(x, a, x, b, 300) else gesture(x, b, x, a, 300)
    }
    fun tapCenter() {
        val m = resources.displayMetrics
        gesture(m.widthPixels / 2f, m.heightPixels / 2f, m.widthPixels / 2f, m.heightPixels / 2f, 50)
    }
}
