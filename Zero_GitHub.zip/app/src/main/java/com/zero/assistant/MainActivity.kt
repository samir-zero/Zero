package com.zero.assistant

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class JarvisView(c: android.content.Context) : View(c) {
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 6000; repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
        }.start()
    }
    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#02070D"))
        val cx = width / 2f; val cy = height * 0.4f
        val base = width * 0.18f
        p.style = Paint.Style.STROKE
        for (i in 0..4) {
            val r = base + i * width * 0.07f
            p.strokeWidth = 4f + (4 - i)
            p.color = Color.argb(220 - i * 30, 0, 200, 255)
            p.setShadowLayer(18f, 0f, 0f, Color.CYAN)
            val rect = RectF(cx - r, cy - r, cx + r, cy + r)
            val dir = if (i % 2 == 0) 1 else -1
            for (k in 0..2) c.drawArc(rect, dir * t * (1 + i * 0.4f) + k * 120f, 70f, false, p)
        }
        p.style = Paint.Style.FILL; p.color = Color.argb(90, 0, 200, 255)
        c.drawCircle(cx, cy, base * 0.6f, p)
    }
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.addView(JarvisView(this))
        val status = TextView(this).apply {
            text = "ZERO ONLINE"; setTextColor(Color.CYAN); textSize = 18f
            gravity = Gravity.CENTER; letterSpacing = 0.3f
        }
        val btn = Button(this).apply {
            text = "ZERO"; setTextColor(Color.CYAN); textSize = 20f
            setBackgroundColor(Color.parseColor("#103040"))
            setOnClickListener { startZero(true) }
        }
        val acc = Button(this).apply {
            text = "Accessibility ON karo (phone control)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(60, 0, 60, 80)
            addView(status); addView(btn); addView(acc)
        }
        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun startZero(greet: Boolean) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != 0) {
            Toast.makeText(this, "Mic permission do", Toast.LENGTH_SHORT).show(); return
        }
        ContextCompat.startForegroundService(this, Intent(this, ZeroService::class.java).putExtra("greet", greet))
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: android.content.Context, i: Intent) {}
}
