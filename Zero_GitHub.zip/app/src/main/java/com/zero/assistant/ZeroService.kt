package com.zero.assistant

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class ZeroService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var ttsReady = false
    private var pendingGreet = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "zero"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Zero", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Zero chal raha hai")
            .setContentText("Sun raha hoon, Samir boss").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        tts.language = Locale("hi", "IN")
        ttsReady = true
        if (pendingGreet) { say("Kaise ho Samir boss?"); pendingGreet = false } else listen()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.getBooleanExtra("greet", false) == true) {
            if (ttsReady) say("Kaise ho Samir boss?") else pendingGreet = true
        }
        return START_STICKY
    }

    private fun say(t: String) {
        rec?.cancel()
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
        h.postDelayed({ waitAndListen() }, 600)
    }
    private fun waitAndListen() {
        if (tts.isSpeaking) h.postDelayed({ waitAndListen() }, 400) else listen()
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) {
                    val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) handle(t.lowercase()) else listen()
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }

    private fun handle(t: String) {
        val acc = ZeroAccessibility.inst
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        when {
            t.contains("kaise ho") || t.contains("hello") ->
                say("Main theek hoon Samir boss. Bolo kya karna hai?")
            t.contains("torch") || t.contains("flash") -> {
                val on = !(t.contains("off") || t.contains("band"))
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                try { cm.setTorchMode(cm.cameraIdList[0], on) } catch (_: Exception) {}
                say(if (on) "Torch on" else "Torch off")
            }
            t.contains("call") || t.contains("phone laga") -> {
                val num = t.filter { it.isDigit() }
                if (num.isNotEmpty()) {
                    startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    say("Call laga raha hoon")
                } else say("Number bolo")
            }
            t.contains("wifi") || t.contains("bluetooth") -> {
                startActivity(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                say("Settings panel khol diya")
            }
            t.contains("volume") && (t.contains("up") || t.contains("badha") || t.contains("zyada")) -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); listen()
            }
            t.contains("volume") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); listen()
            }
            t.contains("home") || t.contains("ghar") -> need(acc) { it.home(); say("Home") }
            t.contains("back") || t.contains("peeche") || t.contains("wapas") -> need(acc) { it.back(); say("Peeche") }
            t.contains("recent") -> need(acc) { it.recents(); say("Recent apps") }
            t.contains("screenshot") -> need(acc) { it.shot(); say("Screenshot liya") }
            t.contains("neeche") || t.contains("scroll down") -> need(acc) { it.swipe(true); listen() }
            t.contains("upar") || t.contains("scroll up") -> need(acc) { it.swipe(false); listen() }
            t.contains("tap") || t.contains("click") || t.contains("dabao") -> need(acc) { it.tapCenter(); listen() }
            t.contains("kholo") || t.contains("open") || t.contains("khol") -> {
                val name = t.replace("kholo", "").replace("khol", "").replace("open", "").replace("do", "").trim()
                val pkg = findApp(name)
                if (pkg != null) {
                    startActivity(packageManager.getLaunchIntentForPackage(pkg)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    say("$name khol raha hoon")
                } else say("$name nahi mila")
            }
            t.contains("stop zero") || t.contains("band karo zero") -> { say("Alvida Samir boss"); h.postDelayed({ stopSelf() }, 2500) }
            else -> say("Samajh nahi aaya, dobara bolo")
        }
    }

    private fun need(a: ZeroAccessibility?, f: (ZeroAccessibility) -> Unit) {
        if (a == null) say("Pehle Accessibility ON karo") else f(a)
    }

    private fun findApp(name: String): String? {
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        return apps.firstOrNull {
            packageManager.getLaunchIntentForPackage(it.packageName) != null &&
            packageManager.getApplicationLabel(it).toString().lowercase().contains(name)
        }?.packageName
    }

    override fun onDestroy() { rec?.destroy(); tts.shutdown(); super.onDestroy() }
}
